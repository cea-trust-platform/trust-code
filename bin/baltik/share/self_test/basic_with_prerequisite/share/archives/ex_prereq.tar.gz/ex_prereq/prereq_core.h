void one_func();

