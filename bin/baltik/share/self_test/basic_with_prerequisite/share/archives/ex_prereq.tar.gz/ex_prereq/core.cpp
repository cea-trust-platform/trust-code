void one_func()
{
  // C++ 17    // works with arrays:
    double myArray[3] = { 1.0, 2.0, 3.0 };  
    //auto [a, b, c] = myArray;


//#if __cplusplus < 201703L
//#error BOUH need 17!!
//#endif

}
